package example.example.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import example.example.pages.PruHomePage;
import example.example.util.GeneralMethods;

@Test(testName = "TestPrulogin", description = "Test description")
public class TestPruloginScenarios extends BaseTest {

	//WebDriver driver;
	
	/**
	 * @author NaveenKumar M Administrator
	 * Function to Invoke application
	 * @throws InterruptedException
	 */
	@Test(priority = 0)
	public void invokeApplication() throws InterruptedException {
		
		// Launch Browser
		//driver = GeneralMethods.openBrowser();
		//driver.manage().window().maximize();
		
		//String AppUrl = GeneralMethods.getData("TestData", 2, "AppUrl");
		driver.get("https://my.webhookrelay.com/login");
		Thread.sleep(3000);	
	}
	
	
	
	/**
	 * @author NaveenKumar M
	 * Function to Validate LoginPositiveValidation
	 * @throws InterruptedException
	 */
	@Test(priority = 1)
	public void LoginPositiveValidation() throws InterruptedException {
		
		//String UserName = GeneralMethods.getData("TestData", 2, "UserName");
		//String Password = GeneralMethods.getData("TestData", 2, "Password");
		
		String UserName = "Jawaharth";
		String Password = "Jrrj@1821";
		
		//driver.findElement(PruHomePage.LoginButton).click();
		driver.manage().timeouts().implicitlyWait(6, TimeUnit.SECONDS);
		driver.findElement(PruHomePage.UserName).sendKeys(UserName);
		driver.findElement(PruHomePage.Password).sendKeys(Password);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.findElement(PruHomePage.LogIn).click();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}
	
	
	
	/**
	 * @author NaveenKumar M
	 * Function to Validate PageTitle
	 * @throws InterruptedException
	 */
	@Test(priority = 2)
	public void PageTitleValidation() throws InterruptedException {
		wait(15);
		//GeneralMethods.waitUntilElementVisible(PruHomePage.LogOut, 59);
		if (driver.getTitle().contains("inancial")) {
			Reporter.log("The page Title matches");
		} else {
			Reporter.log("The page Title Does Not matches");
			Assert.fail("The page Title Does Not matches");
		}
		if (driver.getTitle().contains("inancial")) {
			Reporter.log("The page Title matches");
		} else {
			Reporter.log("The page Title Does Not matches");
			Assert.fail("The page Title Does Not matches");
		}

		/*System.out.println("");
		if (driver.getTitle().contains("DUMMY DATA")) {
			Reporter.log("PASS");
		} else {
			Assert.fail("Failed for dummy data");
		}*/
	}
	
	
	
	
	/**
	 * @author NaveenKumar M
	 * Function to Close Browser
	 * @throws InterruptedException
	 */
//	@AfterClass
//	public void closeBrowser() throws InterruptedException {
//		driver.close();
//	} 

}
