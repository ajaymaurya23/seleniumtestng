package example.example.pages;

import org.openqa.selenium.By;

public class PruHomePage {
	
	//Prudential home page elements
	
	/*public static final By CloseModalWindow = By.xpath("//*[@id='themecontent']/div[3]/div[2]/div[1]/div");
	public static final By LoginButton = By.xpath("//*[@id='toprow-right']//a[contains(@data-qa,'login-button-desktop')]");
	public static final By UserName = By.xpath("//*[@id='username']");
	public static final By Password = By.xpath("//*[@id='password']");
	public static final By LogIn = By.xpath("//*[@id='pruws_row2']//button[contains(.,'Log In')]");
	public static final By LogOut = By.xpath("//*[@id='log-out']");
	*/
	
	public static final By CloseModalWindow = By.xpath("//*[@id='themecontent']/div[3]/div[2]/div[1]/div");
	//public static final By LoginButton = By.xpath("//*[@id='toprow-right']//a[contains(@data-qa,'Sign in')]");
	//public static final By LoginButton = By.xpath("//*[@id=\"app\"]/div[2]/div/div/div/div[2]/div/div/div[1]/a/button/span");
	public static final By UserName = By.xpath("//*[@id='username']");
	public static final By Password = By.xpath("//*[@id='password']");
	public static final By LogIn = By.xpath("//*[@id=\"app\"]/div/div/div/div/div[2]/div/div/div[3]/form/div[4]/div/button/span");
	public static final By LogOut = By.xpath("//*[@id=\"list-item-190\"]/div");
	
	
}
