package example.example.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GeneralMethods {

	public static WebDriver driver;

	/**
	 * @author
	 * @param FileInput Stream, 
	 * Function to load Workbook
	 * @param Test data workbook path
	 */
	public static XSSFWorkbook getWorkbook() {

		XSSFWorkbook wb = null;
		String ExcelPath = getPropertyValue("TestDataPath");
		
		try {
			FileInputStream fis = new FileInputStream(ExcelPath);
			try {
				wb = new XSSFWorkbook(fis);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return wb;
	}

	/**
	 * @author
	 * @param FileInputStream, 
	 * Function to load Workbook
	 * @param sheetName TestCaseNo Column
	 */
	
	@SuppressWarnings("static-access")
	public static String getData(String sheetName, int TestCaseNo, String Column) {
		
		String stringData = "";
		XSSFSheet sh = getWorkbook().getSheet(sheetName);

		int rows = sh.getRow(0).getLastCellNum();
		String ColumnTitle[] = new String[rows];

		for (int i = 0; i < rows; i++) {
			ColumnTitle[i] = sh.getRow(0).getCell(i).getStringCellValue();
		}

		for (int j = 0; j < rows; j++) {

			if (ColumnTitle[j].contains(Column)) {
				try {
					stringData = sh.getRow(TestCaseNo).getCell(j)
							.getStringCellValue();

				} catch (Exception e) {
					double numericData = sh.getRow(TestCaseNo).getCell(j)
							.getNumericCellValue();
					stringData = stringData.valueOf(numericData);
				}
			}
		}
		return stringData;
	}

	/**
	 * @author Naveen Kumar M 
	 * Function to call the Browser at Runtime
	 * @param Browser
	 * @param Driver Path
	 * @return Browser Driver
	 */
	static String huburl;
	@SuppressWarnings("deprecation")
	public static WebDriver openBrowser() {

		String Browser = getPropertyValue("Browser");
		DesiredCapabilities ds = new DesiredCapabilities();

		switch (Browser) {

		case "Chrome":
			ds = DesiredCapabilities.chrome();
			ds.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			String ChromeDriverPath = getPropertyValue("ChromeDriverPath");
			System.setProperty("webdriver.chrome.driver", ChromeDriverPath);
			driver = new ChromeDriver(ds);

			break;
			
		case "GRIDChrome":
			
			DesiredCapabilities cap = DesiredCapabilities.chrome();
			cap.setPlatform(org.openqa.selenium.Platform.WINDOWS);
			huburl = getPropertyValue("HubUrl");
			try {
				
				driver = new RemoteWebDriver(new URL(huburl),cap);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			break;

		case "FireFox":
			ds = DesiredCapabilities.firefox();
			ds.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			String FirefoxDriverPath = getPropertyValue("FirefoxDriverPath");
			System.setProperty("webdriver.gecko.driver", FirefoxDriverPath);
			driver = new FirefoxDriver(ds);
			
			break;

		case "IE":

			String IEDriverPath = getPropertyValue("IEDriverPath");
			System.setProperty("webdriver.ie.driver", IEDriverPath);
			driver = new InternetExplorerDriver();
			break;
		}
		return driver;
	}

	/**
	 * @author Naveen Kumar M
	 * Function to get value from property file
	 * @return value
	 * @param Key
	 */
	
	public static String getPropertyValue(String string) {
		
		String stringValue = "";
		Properties prop = new Properties();
		try {
			FileInputStream fs = new FileInputStream("./TestParameters.properties");
			prop.load(fs);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		stringValue = prop.getProperty(string);
		return stringValue;
	}
	
	public static void waitUntilElementVisible(By element, int timeout){
		WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.visibilityOfElementLocated(element));
	}
}
